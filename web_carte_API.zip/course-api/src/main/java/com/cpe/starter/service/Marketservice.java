package com.cpe.starter.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.starter.modele.Card;
import com.cpe.starter.repository.CardRepository;
import com.cpe.starter.repository.MarketRepository;

@Service
public class Marketservice {
	
	@Autowired
	MarketRepository marketRepository;
	
	@Autowired
	CardRepository cardRepository;
	
	public boolean addcardtomarket(Card C) {
		marketRepository.save(C);
		return true;

	}
	
	public List<Card> getallcardmarket(){
		return (List<Card>) marketRepository.findAll();
	}
	
	public boolean soldcard(int id) {
		if(marketRepository.getcard(id)==null) {
			Card C=cardRepository.findById(id);
			marketRepository.save(C);
			return true;
		}
		else return false;
	}
	
}
