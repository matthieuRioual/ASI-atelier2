package com.cpe.starter.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cpe.starter.modele.Card;

public interface MarketRepository extends CrudRepository<Card, Integer> {

    @Query("select a from Card a where a.id=?1")
	public Card getcard(int id);

}
